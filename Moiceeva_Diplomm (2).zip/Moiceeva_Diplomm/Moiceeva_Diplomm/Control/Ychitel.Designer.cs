﻿
namespace Moiceeva_Diplomm.Control
{
    partial class Ychitel
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Bt_Delete = new System.Windows.Forms.Button();
            this.Bt_Insert = new System.Windows.Forms.Button();
            this.Bt_Update = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Bt_Predmet = new System.Windows.Forms.Button();
            this.Tx_Otch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Tx_Fam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Tx_Ima = new System.Windows.Forms.TextBox();
            this.Cb_User = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Dt_Ychittel = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dt_Ychittel)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Bt_Delete);
            this.panel1.Controls.Add(this.Bt_Insert);
            this.panel1.Controls.Add(this.Bt_Update);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1670, 90);
            this.panel1.TabIndex = 0;
            // 
            // Bt_Delete
            // 
            this.Bt_Delete.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Delete.Location = new System.Drawing.Point(458, 27);
            this.Bt_Delete.Name = "Bt_Delete";
            this.Bt_Delete.Size = new System.Drawing.Size(241, 44);
            this.Bt_Delete.TabIndex = 27;
            this.Bt_Delete.Text = "Удалить запись";
            this.Bt_Delete.UseVisualStyleBackColor = true;
            // 
            // Bt_Insert
            // 
            this.Bt_Insert.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Insert.Location = new System.Drawing.Point(20, 27);
            this.Bt_Insert.Name = "Bt_Insert";
            this.Bt_Insert.Size = new System.Drawing.Size(197, 44);
            this.Bt_Insert.TabIndex = 25;
            this.Bt_Insert.Text = "Добавить запись";
            this.Bt_Insert.UseVisualStyleBackColor = true;
            // 
            // Bt_Update
            // 
            this.Bt_Update.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Update.Location = new System.Drawing.Point(223, 27);
            this.Bt_Update.Name = "Bt_Update";
            this.Bt_Update.Size = new System.Drawing.Size(229, 44);
            this.Bt_Update.TabIndex = 26;
            this.Bt_Update.Text = "Изменить запись";
            this.Bt_Update.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Bt_Predmet);
            this.panel2.Controls.Add(this.Tx_Otch);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Tx_Fam);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.Tx_Ima);
            this.panel2.Controls.Add(this.Cb_User);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(499, 467);
            this.panel2.TabIndex = 1;
            // 
            // Bt_Predmet
            // 
            this.Bt_Predmet.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Predmet.Location = new System.Drawing.Point(85, 347);
            this.Bt_Predmet.Name = "Bt_Predmet";
            this.Bt_Predmet.Size = new System.Drawing.Size(241, 44);
            this.Bt_Predmet.TabIndex = 28;
            this.Bt_Predmet.Text = "Добавить предмет";
            this.Bt_Predmet.UseVisualStyleBackColor = true;
            // 
            // Tx_Otch
            // 
            this.Tx_Otch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.Tx_Otch.Location = new System.Drawing.Point(20, 198);
            this.Tx_Otch.Name = "Tx_Otch";
            this.Tx_Otch.Size = new System.Drawing.Size(450, 26);
            this.Tx_Otch.TabIndex = 36;
            this.Tx_Otch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Otch_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(15, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(258, 25);
            this.label1.TabIndex = 35;
            this.label1.Text = "Введите отчество учителя";
            // 
            // Tx_Fam
            // 
            this.Tx_Fam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.Tx_Fam.Location = new System.Drawing.Point(20, 130);
            this.Tx_Fam.Name = "Tx_Fam";
            this.Tx_Fam.Size = new System.Drawing.Size(450, 26);
            this.Tx_Fam.TabIndex = 34;
            this.Tx_Fam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Fam_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(16, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(267, 25);
            this.label2.TabIndex = 33;
            this.label2.Text = "Введите фамилию учителя";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(15, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 25);
            this.label3.TabIndex = 32;
            this.label3.Text = "Введите имя учителя";
            // 
            // Tx_Ima
            // 
            this.Tx_Ima.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.Tx_Ima.Location = new System.Drawing.Point(20, 68);
            this.Tx_Ima.Name = "Tx_Ima";
            this.Tx_Ima.Size = new System.Drawing.Size(450, 26);
            this.Tx_Ima.TabIndex = 31;
            this.Tx_Ima.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Ima_KeyPress);
            // 
            // Cb_User
            // 
            this.Cb_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold);
            this.Cb_User.FormattingEnabled = true;
            this.Cb_User.Location = new System.Drawing.Point(20, 263);
            this.Cb_User.Name = "Cb_User";
            this.Cb_User.Size = new System.Drawing.Size(450, 30);
            this.Cb_User.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(15, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(284, 25);
            this.label4.TabIndex = 29;
            this.label4.Text = "Выберите имя пользователя";
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(499, 520);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1171, 37);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(1608, 90);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(62, 430);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Dt_Ychittel);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(499, 90);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1109, 430);
            this.panel5.TabIndex = 4;
            // 
            // Dt_Ychittel
            // 
            this.Dt_Ychittel.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ychittel.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.Dt_Ychittel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dt_Ychittel.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.Dt_Ychittel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dt_Ychittel.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Dt_Ychittel.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dt_Ychittel.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.Dt_Ychittel.ColumnHeadersHeight = 40;
            this.Dt_Ychittel.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.Dt_Ychittel.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ychittel.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ychittel.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.Dt_Ychittel.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Dt_Ychittel.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.Dt_Ychittel.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Dt_Ychittel.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.Dt_Ychittel.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ychittel.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Dt_Ychittel.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.Dt_Ychittel.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.Dt_Ychittel.CurrentTheme.Name = null;
            this.Dt_Ychittel.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Dt_Ychittel.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ychittel.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ychittel.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.Dt_Ychittel.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Dt_Ychittel.DefaultCellStyle = dataGridViewCellStyle3;
            this.Dt_Ychittel.EnableHeadersVisualStyles = false;
            this.Dt_Ychittel.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Dt_Ychittel.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.Dt_Ychittel.HeaderBgColor = System.Drawing.Color.Empty;
            this.Dt_Ychittel.HeaderForeColor = System.Drawing.Color.White;
            this.Dt_Ychittel.Location = new System.Drawing.Point(34, 3);
            this.Dt_Ychittel.Name = "Dt_Ychittel";
            this.Dt_Ychittel.RowHeadersVisible = false;
            this.Dt_Ychittel.RowHeadersWidth = 51;
            this.Dt_Ychittel.RowTemplate.Height = 40;
            this.Dt_Ychittel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dt_Ychittel.Size = new System.Drawing.Size(1069, 424);
            this.Dt_Ychittel.TabIndex = 38;
            this.Dt_Ychittel.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.Dt_Ychittel.DoubleClick += new System.EventHandler(this.Dt_Ychittel_DoubleClick);
            // 
            // Ychitel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Ychitel";
            this.Size = new System.Drawing.Size(1670, 557);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dt_Ychittel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Bt_Delete;
        private System.Windows.Forms.Button Bt_Insert;
        private System.Windows.Forms.Button Bt_Update;
        private System.Windows.Forms.ComboBox Cb_User;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Tx_Otch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Tx_Fam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tx_Ima;
        private System.Windows.Forms.Button Bt_Predmet;
        private Bunifu.UI.WinForms.BunifuDataGridView Dt_Ychittel;
    }
}
