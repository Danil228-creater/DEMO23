﻿
namespace Moiceeva_Diplomm.Control
{
    partial class Yceniki
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Bt_Insert_Klass = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Bt_Delete = new System.Windows.Forms.Button();
            this.Bt_Update = new System.Windows.Forms.Button();
            this.Bt_Insert = new System.Windows.Forms.Button();
            this.Cb_Klass = new System.Windows.Forms.ComboBox();
            this.Cb_User = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Tx_Otch = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Tx_Fam = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Tx_Ima = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Dt_Ucheniki = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Bt_Obnova = new System.Windows.Forms.Button();
            this.CB_Poick = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dt_Ucheniki)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Bt_Insert_Klass);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Bt_Delete);
            this.panel1.Controls.Add(this.Bt_Update);
            this.panel1.Controls.Add(this.Bt_Insert);
            this.panel1.Controls.Add(this.Cb_Klass);
            this.panel1.Controls.Add(this.Cb_User);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.Tx_Otch);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Tx_Fam);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Tx_Ima);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(678, 557);
            this.panel1.TabIndex = 0;
            // 
            // Bt_Insert_Klass
            // 
            this.Bt_Insert_Klass.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Insert_Klass.Location = new System.Drawing.Point(452, 343);
            this.Bt_Insert_Klass.Name = "Bt_Insert_Klass";
            this.Bt_Insert_Klass.Size = new System.Drawing.Size(211, 44);
            this.Bt_Insert_Klass.TabIndex = 38;
            this.Bt_Insert_Klass.Text = "Добавить класс";
            this.Bt_Insert_Klass.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(22, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(396, 31);
            this.label7.TabIndex = 37;
            this.label7.Text = "Персональные данные ученика";
            // 
            // Bt_Delete
            // 
            this.Bt_Delete.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Delete.Location = new System.Drawing.Point(452, 293);
            this.Bt_Delete.Name = "Bt_Delete";
            this.Bt_Delete.Size = new System.Drawing.Size(211, 44);
            this.Bt_Delete.TabIndex = 36;
            this.Bt_Delete.Text = "Удалить";
            this.Bt_Delete.UseVisualStyleBackColor = true;
            // 
            // Bt_Update
            // 
            this.Bt_Update.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Update.Location = new System.Drawing.Point(452, 243);
            this.Bt_Update.Name = "Bt_Update";
            this.Bt_Update.Size = new System.Drawing.Size(211, 44);
            this.Bt_Update.TabIndex = 35;
            this.Bt_Update.Text = "Изменить запись";
            this.Bt_Update.UseVisualStyleBackColor = true;
            // 
            // Bt_Insert
            // 
            this.Bt_Insert.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Insert.Location = new System.Drawing.Point(452, 193);
            this.Bt_Insert.Name = "Bt_Insert";
            this.Bt_Insert.Size = new System.Drawing.Size(214, 44);
            this.Bt_Insert.TabIndex = 34;
            this.Bt_Insert.Text = "Добавить запись";
            this.Bt_Insert.UseVisualStyleBackColor = true;
            // 
            // Cb_Klass
            // 
            this.Cb_Klass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.Cb_Klass.FormattingEnabled = true;
            this.Cb_Klass.Location = new System.Drawing.Point(18, 335);
            this.Cb_Klass.Name = "Cb_Klass";
            this.Cb_Klass.Size = new System.Drawing.Size(412, 28);
            this.Cb_Klass.TabIndex = 33;
            // 
            // Cb_User
            // 
            this.Cb_User.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.Cb_User.FormattingEnabled = true;
            this.Cb_User.Location = new System.Drawing.Point(18, 397);
            this.Cb_User.Name = "Cb_User";
            this.Cb_User.Size = new System.Drawing.Size(412, 28);
            this.Cb_User.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(14, 373);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(210, 19);
            this.label6.TabIndex = 31;
            this.label6.Text = "Выберите имя пользователя";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(14, 313);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 19);
            this.label5.TabIndex = 29;
            this.label5.Text = "Выберете класс ";
            // 
            // Tx_Otch
            // 
            this.Tx_Otch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.Tx_Otch.Location = new System.Drawing.Point(18, 275);
            this.Tx_Otch.Name = "Tx_Otch";
            this.Tx_Otch.Size = new System.Drawing.Size(412, 27);
            this.Tx_Otch.TabIndex = 28;
            this.Tx_Otch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Otch_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(14, 253);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(192, 19);
            this.label4.TabIndex = 27;
            this.label4.Text = "Введите отчество ученика";
            // 
            // Tx_Fam
            // 
            this.Tx_Fam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.Tx_Fam.Location = new System.Drawing.Point(18, 215);
            this.Tx_Fam.Name = "Tx_Fam";
            this.Tx_Fam.Size = new System.Drawing.Size(412, 27);
            this.Tx_Fam.TabIndex = 26;
            this.Tx_Fam.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Fam_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(14, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 19);
            this.label2.TabIndex = 25;
            this.label2.Text = "Введите фамилию ученика";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(14, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 19);
            this.label3.TabIndex = 24;
            this.label3.Text = "Введите имя ученика";
            // 
            // Tx_Ima
            // 
            this.Tx_Ima.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold);
            this.Tx_Ima.Location = new System.Drawing.Point(18, 159);
            this.Tx_Ima.Name = "Tx_Ima";
            this.Tx_Ima.Size = new System.Drawing.Size(412, 27);
            this.Tx_Ima.TabIndex = 23;
            this.Tx_Ima.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Tx_Ima_KeyPress);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.flowLayoutPanel2);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(678, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(992, 557);
            this.panel2.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Dt_Ucheniki);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(17, 95);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(933, 425);
            this.panel5.TabIndex = 4;
            // 
            // Dt_Ucheniki
            // 
            this.Dt_Ucheniki.AllowCustomTheming = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ucheniki.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.Dt_Ucheniki.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dt_Ucheniki.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.Dt_Ucheniki.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Dt_Ucheniki.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.Dt_Ucheniki.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dt_Ucheniki.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.Dt_Ucheniki.ColumnHeadersHeight = 40;
            this.Dt_Ucheniki.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.Dt_Ucheniki.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ucheniki.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ucheniki.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.Dt_Ucheniki.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Dt_Ucheniki.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.Dt_Ucheniki.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Dt_Ucheniki.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.Dt_Ucheniki.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ucheniki.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.Dt_Ucheniki.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.Dt_Ucheniki.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.Dt_Ucheniki.CurrentTheme.Name = null;
            this.Dt_Ucheniki.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.Dt_Ucheniki.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.Dt_Ucheniki.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.Dt_Ucheniki.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.Dt_Ucheniki.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Dt_Ucheniki.DefaultCellStyle = dataGridViewCellStyle6;
            this.Dt_Ucheniki.EnableHeadersVisualStyles = false;
            this.Dt_Ucheniki.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.Dt_Ucheniki.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.Dt_Ucheniki.HeaderBgColor = System.Drawing.Color.Empty;
            this.Dt_Ucheniki.HeaderForeColor = System.Drawing.Color.White;
            this.Dt_Ucheniki.Location = new System.Drawing.Point(3, 3);
            this.Dt_Ucheniki.Name = "Dt_Ucheniki";
            this.Dt_Ucheniki.RowHeadersVisible = false;
            this.Dt_Ucheniki.RowHeadersWidth = 51;
            this.Dt_Ucheniki.RowTemplate.Height = 40;
            this.Dt_Ucheniki.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dt_Ucheniki.Size = new System.Drawing.Size(926, 419);
            this.Dt_Ucheniki.TabIndex = 0;
            this.Dt_Ucheniki.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.Dt_Ucheniki.DoubleClick += new System.EventHandler(this.Dt_Ucheniki_DoubleClick);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(950, 95);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(42, 425);
            this.flowLayoutPanel2.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 95);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 425);
            this.panel4.TabIndex = 2;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 520);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(992, 37);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Bt_Obnova);
            this.panel3.Controls.Add(this.CB_Poick);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(992, 95);
            this.panel3.TabIndex = 0;
            // 
            // Bt_Obnova
            // 
            this.Bt_Obnova.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bt_Obnova.Location = new System.Drawing.Point(427, 47);
            this.Bt_Obnova.Name = "Bt_Obnova";
            this.Bt_Obnova.Size = new System.Drawing.Size(231, 30);
            this.Bt_Obnova.TabIndex = 37;
            this.Bt_Obnova.Text = "Сбросить фильтр";
            this.Bt_Obnova.UseVisualStyleBackColor = true;
            // 
            // CB_Poick
            // 
            this.CB_Poick.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CB_Poick.FormattingEnabled = true;
            this.CB_Poick.Location = new System.Drawing.Point(158, 49);
            this.CB_Poick.Name = "CB_Poick";
            this.CB_Poick.Size = new System.Drawing.Size(244, 28);
            this.CB_Poick.TabIndex = 1;
            this.CB_Poick.SelectedIndexChanged += new System.EventHandler(this.CB_Poick_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(154, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Класс";
            // 
            // Yceniki
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Yceniki";
            this.Size = new System.Drawing.Size(1670, 557);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dt_Ucheniki)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox CB_Poick;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Tx_Otch;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Tx_Fam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tx_Ima;
        private System.Windows.Forms.ComboBox Cb_Klass;
        private System.Windows.Forms.ComboBox Cb_User;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Bt_Delete;
        private System.Windows.Forms.Button Bt_Update;
        private System.Windows.Forms.Button Bt_Insert;
        private System.Windows.Forms.Button Bt_Obnova;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Bt_Insert_Klass;
        private Bunifu.UI.WinForms.BunifuDataGridView Dt_Ucheniki;
    }
}
